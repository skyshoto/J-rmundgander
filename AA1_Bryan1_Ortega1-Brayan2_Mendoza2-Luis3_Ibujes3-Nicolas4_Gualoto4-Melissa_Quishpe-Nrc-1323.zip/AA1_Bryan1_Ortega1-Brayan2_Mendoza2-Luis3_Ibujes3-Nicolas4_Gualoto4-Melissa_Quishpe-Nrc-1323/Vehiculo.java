public class Vehiculo {
    private static int contadorId = 1; // Atributo estático para generar IDs únicos
    private final int id; // ID único, final para que no cambie
    private String placa;
    private String marca;
    private String modelo;
    private String tipo; // Ejemplo: "auto", "moto", "camión"
    private boolean estacionado;

    // Constructor que inicializa los atributos
    public Vehiculo(String placa, String marca, String modelo, String tipo) {
        this.id = contadorId++;
        this.placa = placa;
        this.marca = marca;
        this.modelo = modelo;
        this.tipo = tipo;
        this.estacionado = false; // Por defecto, no está estacionado
    }

    // Métodos getter y setter
    public int getId() {
        return id;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public boolean isEstacionado() {
        return estacionado;
    }

    public void setEstacionado(boolean estacionado) {
        this.estacionado = estacionado;
    }

    @Override
    public String toString() {
        return "ID: " + id + ", Placa: " + placa + ", Marca: " + marca + ", Modelo: " + modelo + ", Tipo: " + tipo + ", Estacionado: " + (estacionado ? "Sí" : "No");
    }
}
