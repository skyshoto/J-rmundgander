import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Parqueadero parqueadero = new Parqueadero();
        Scanner scanner = new Scanner(System.in);
        int opcion = 0;

        do {
            System.out.println("\n--- Menú del Parqueadero ---");
            System.out.println("1. Registrar cliente");
            System.out.println("2. Registrar vehículo");
            System.out.println("3. Asociar vehículo a cliente");
            System.out.println("4. Actualizar estado en el parqueadero del vehículp");
            System.out.println("5. Mostrar vehículos estacionados");
            System.out.println("6. Mostrar vehículos de un cliente");
            System.out.println("7. Salir");
            System.out.print("Ingrese una opción: ");

            try {
                opcion = scanner.nextInt();
                scanner.nextLine(); // Limpiar el buffer de entrada
            } catch (InputMismatchException e) {
                System.out.println("Opción no válida, debe ser un número.");
                scanner.nextLine(); // Limpiar el buffer de entrada
                continue;
            }

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese el nombre del cliente: ");
                    String nombreCliente = scanner.nextLine();
                    parqueadero.registrarCliente(nombreCliente);
                    break;

                case 2:
                    System.out.print("Ingrese la placa del vehículo: ");
                    String placa = scanner.nextLine();
                    System.out.print("Ingrese la marca del vehículo: ");
                    String marca = scanner.nextLine();
                    System.out.print("Ingrese el modelo del vehículo: ");
                    String modelo = scanner.nextLine();
                    System.out.print("Ingrese el tipo del vehículo (auto, moto, camión): ");
                    String tipo = scanner.nextLine();
                    parqueadero.registrarVehiculo(placa, marca, modelo, tipo);
                    break;

                case 3:
                    System.out.println("\n--- Lista de clientes ---");
                    parqueadero.mostrarClientesRegistrados();
                    
                    try {
                        System.out.print("\nIngrese el ID del cliente: ");
                        int idClienteAsociar = scanner.nextInt();
                        scanner.nextLine(); // Limpiar el buffer de entrada
                        
                        System.out.println("\n--- Lista de vehículos disponibles ---");
                        parqueadero.mostrarVehiculosEstacionados();
                        
                        System.out.print("\nIngrese el ID del vehículo a asociar: ");
                        int idVehiculoAsociar = scanner.nextInt();
                        scanner.nextLine(); // Limpiar el buffer de entrada
                        
                        parqueadero.asociarVehiculo(idClienteAsociar, idVehiculoAsociar);
                    } catch (InputMismatchException e) {
                        System.out.println("Error: El ID debe ser un número.");
                        scanner.nextLine(); // Limpiar el buffer de entrada
                    }
                    break;

                case 4:
                    System.out.println("\n--- Lista de clientes con vehículos asociados ---");
                    parqueadero.mostrarClientesConVehiculos();
                    
                    try {
                        System.out.print("\nIngrese el ID del cliente: ");
                        int idClienteDesasociar = scanner.nextInt();
                        scanner.nextLine(); // Limpiar el buffer de entrada
                        
                        System.out.println("\n--- Vehículos asociados ---");
                        parqueadero.mostrarVehiculosDeCliente(idClienteDesasociar);
                        
                        System.out.print("\nIngrese el ID del vehículo a desasociar: ");
                        int idVehiculoDesasociar = scanner.nextInt();
                        scanner.nextLine(); // Limpiar el buffer de entrada
                        
                        parqueadero.desasociarVehiculo(idClienteDesasociar, idVehiculoDesasociar);
                    } catch (InputMismatchException e) {
                        System.out.println("Error: El ID debe ser un número.");
                        scanner.nextLine(); // Limpiar el buffer de entrada
                    }
                    break;

                case 5:
                    System.out.println("\n--- Vehículos estacionados ---");
                    parqueadero.mostrarVehiculosEstacionados();
                    break;

                case 6:
                    System.out.print("Ingrese el ID del cliente para mostrar sus vehículos: ");
                    int idClienteMostrar = scanner.nextInt();
                    scanner.nextLine(); // Limpiar el buffer de entrada
                    parqueadero.mostrarVehiculosDeCliente(idClienteMostrar);
                    break;

                case 7:
                    System.out.println("Saliendo...");
                    break;

                default:
                    System.out.println("Opción no válida.");
            }
        } while (opcion != 8);
        
        scanner.close();
    }
}
