import java.util.ArrayList;

public class Cliente {
    private static int contadorId = 1; // Atributo estático
    private final int id; // ID único, final para no permitir cambios
    private String nombre;
    private ArrayList<Vehiculo> vehiculos;

    public Cliente(String nombre) {
        this.id = contadorId++;
        this.nombre = nombre;
        this.vehiculos = new ArrayList<>();
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void agregarVehiculo(Vehiculo vehiculo) {
        vehiculos.add(vehiculo);
    }

    public void removerVehiculo(Vehiculo vehiculo) {
        vehiculos.remove(vehiculo);
    }

    public ArrayList<Vehiculo> getVehiculos() {
        return vehiculos;
    }

    @Override
    public String toString() {
        return "ID: " + id + ", Nombre: " + nombre + ", Vehículos: " + vehiculos.size();
    }
}
