import java.util.ArrayList;

public class Parqueadero {
    private ArrayList<Vehiculo> vehiculos;
    private ArrayList<Cliente> clientes;

    // Constructor
    public Parqueadero() {
        this.vehiculos = new ArrayList<>();
        this.clientes = new ArrayList<>();
    }

    // Método para registrar un nuevo vehículo
    public void registrarVehiculo(String placa, String marca, String modelo, String tipo) {
        Vehiculo vehiculo = new Vehiculo(placa, marca, modelo, tipo);
        vehiculos.add(vehiculo);
        System.out.println("Vehículo registrado: " + vehiculo.getPlaca() + " con ID: " + vehiculo.getId());
    }

    // Método para registrar un cliente
    public void registrarCliente(String nombre) {
        Cliente cliente = new Cliente(nombre);
        clientes.add(cliente);
        System.out.println("Cliente registrado: " + cliente.getNombre() + " con ID: " + cliente.getId());
    }

    // Método para asociar un vehículo a un cliente
    public void asociarVehiculo(int idCliente, int idVehiculo) {
        Cliente cliente = buscarCliente(idCliente);
        Vehiculo vehiculo = buscarVehiculo(idVehiculo);

        if (cliente != null && vehiculo != null) {
            if (!vehiculo.isEstacionado()) {
                vehiculo.setEstacionado(true);
                cliente.agregarVehiculo(vehiculo);
                System.out.println("El vehículo '" + vehiculo.getPlaca() + "' ha sido asociado a " + cliente.getNombre());
            } else {
                System.out.println("El vehículo ya está estacionado.");
            }
        } else {
            System.out.println("Cliente o vehículo no encontrado.");
        }
    }

    // Método para desasociar un vehículo de un cliente
    public void desasociarVehiculo(int idCliente, int idVehiculo) {
        Cliente cliente = buscarCliente(idCliente);
        Vehiculo vehiculo = buscarVehiculo(idVehiculo);

        if (cliente != null && vehiculo != null) {
            if (vehiculo.isEstacionado()) {
                vehiculo.setEstacionado(false);
                cliente.removerVehiculo(vehiculo);
                System.out.println("El vehículo '" + vehiculo.getPlaca() + "' ha sido desasociado de " + cliente.getNombre());
            } else {
                System.out.println("El vehículo no está estacionado.");
            }
        } else {
            System.out.println("Cliente o vehículo no encontrado.");
        }
    }

    // Método para mostrar los vehículos estacionados
    public void mostrarVehiculosEstacionados() {
        System.out.println("\n--- Lista de vehículos estacionados ---");
        boolean hayVehiculos = false;
        for (Vehiculo vehiculo : vehiculos) {
            if (vehiculo.isEstacionado()) {
                System.out.println("ID: " + vehiculo.getId() + " - Placa: " + vehiculo.getPlaca() + " - Marca: " + vehiculo.getMarca());
                hayVehiculos = true;
            }
        }
        if (!hayVehiculos) {
            System.out.println(" No hay vehículos estacionados.");
        }
    }

    // Método para mostrar los clientes registrados
    public void mostrarClientesRegistrados() {
        System.out.println("\n--- Lista de clientes registrados ---");
        if (clientes.isEmpty()) {
            System.out.println(" No hay clientes registrados.");
        } else {
            for (Cliente cliente : clientes) {
                System.out.println("ID: " + cliente.getId() + " - Nombre: " + cliente.getNombre());
            }
        }
    }

    // Método para mostrar los clientes con vehículos asociados
    public void mostrarClientesConVehiculos() {
        System.out.println("\n--- Lista de clientes con vehículos asociados ---");
        boolean hayClientesConVehiculos = false;

        for (Cliente cliente : clientes) {
            if (!cliente.getVehiculos().isEmpty()) {
                System.out.println(" ID: " + cliente.getId() + " - Nombre: " + cliente.getNombre() + 
                                   " - Vehículos asociados: " + cliente.getVehiculos().size());
                hayClientesConVehiculos = true;
            }
        }

        if (!hayClientesConVehiculos) {
            System.out.println("No hay clientes con vehículos asociados.");
        }
    }

    // Método para mostrar los vehículos asociados a un cliente específico
    public void mostrarVehiculosDeCliente(int idCliente) {
        Cliente cliente = buscarCliente(idCliente);

        if (cliente != null) {
            System.out.println("\n--- Vehículos asociados al cliente " + cliente.getNombre() + " ---");
            if (!cliente.getVehiculos().isEmpty()) {
                for (Vehiculo vehiculo : cliente.getVehiculos()) {
                    System.out.println("ID: " + vehiculo.getId() + " - Placa: " + vehiculo.getPlaca() + " - Marca: " + vehiculo.getMarca());
                }
            } else {
                System.out.println(" El cliente no tiene vehículos asociados.");
            }
        } else {
            System.out.println("Cliente no encontrado.");
        }
    }

    // Método para buscar un vehículo
    private Vehiculo buscarVehiculo(int idVehiculo) {
        for (Vehiculo vehiculo : vehiculos) {
            if (vehiculo.getId() == idVehiculo) {
                return vehiculo;
            }
        }
        return null;
    }

    // Método para buscar un cliente
    private Cliente buscarCliente(int idCliente) {
        for (Cliente cliente : clientes) {
            if (cliente.getId() == idCliente) {
                return cliente;
            }
        }
        return null;
    }
}
