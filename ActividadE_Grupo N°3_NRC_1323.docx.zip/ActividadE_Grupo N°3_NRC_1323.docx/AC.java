import java.util.ArrayList;

// Clase Mesa
class Mesa {
    public int numero;
    public int capacidad;
    public boolean reservada;

    public Mesa(int numero, int capacidad) {
        this.numero = numero;
        this.capacidad = capacidad;
        this.reservada = false;
    }

    public void reservar() {
        if (!reservada) {
            reservada = true;
            System.out.println("Mesa " + numero + " reservada.");
        } else {
            System.out.println("La mesa " + numero + " ya está reservada.");
        }
    }

    public void liberar() {
        if (reservada) {
            reservada = false;
            System.out.println("Mesa " + numero + " liberada.");
        } else {
            System.out.println("La mesa " + numero + " ya está disponible.");
        }
    }

    public int getNumero() {
        return numero;
    }

    public boolean isReservada() {
        return reservada;
    }
}

// Clase Cliente
class Cliente {
    public String nombre;
    public String telefono;

    public Cliente(String nombre, String telefono) {
        this.nombre = nombre;
        this.telefono = telefono;
    }

    public Reserva realizarReserva(String fecha, String hora, Mesa mesa) {
        if (!mesa.isReservada()) {
            mesa.reservar();
            return new Reserva(fecha, hora, this, mesa);
        } else {
            System.out.println("La mesa " + mesa.getNumero() + " no está disponible.");
            return null;
        }
    }

    public String getNombre() {
        return nombre;
    }
}

// Clase Reserva
class Reserva {
    public String fecha;
    public String hora;
    public Cliente cliente;
    public Mesa mesa;
    public boolean confirmada;

    public Reserva(String fecha, String hora, Cliente cliente, Mesa mesa) {
        this.fecha = fecha;
        this.hora = hora;
        this.cliente = cliente;
        this.mesa = mesa;
        this.confirmada = false;
    }

    public void confirmar() {
        confirmada = true;
        System.out.println("Reserva confirmada para " + cliente.getNombre() + " en la mesa " + mesa.getNumero());
    }

    public void finalizar() {
        mesa.liberar();
        System.out.println("Reserva finalizada para " + cliente.getNombre());
    }
}

// Clase Empleado
class Empleado {
    public int idEmpleado;
    public String nombre;

    public Empleado(int idEmpleado, String nombre) {
        this.idEmpleado = idEmpleado;
        this.nombre = nombre;
    }

    public void gestionarReservas(Reserva reserva) {
        reserva.confirmar();
    }

    public void asignarMesa(Cliente cliente, Mesa mesa, String fecha, String hora) {
        cliente.realizarReserva(fecha, hora, mesa);
    }
}

// Clase Restaurante
class Restaurante {
    public String nombre;
    public String direccion;
    public ArrayList<Mesa> mesas;

    public Restaurante(String nombre, String direccion) {
        this.nombre = nombre;
        this.direccion = direccion;
        this.mesas = new ArrayList<>();
    }

    public void agregarMesa(Mesa mesa) {
        mesas.add(mesa);
        System.out.println("Mesa " + mesa.getNumero() + " agregada al restaurante.");
    }

    public void listarMesas() {
        System.out.println("Mesas en el restaurante:");
        for (Mesa mesa : mesas) {
            String estado = mesa.isReservada() ? "Reservada" : "Disponible";
            System.out.println("Mesa " + mesa.getNumero() + " - Capacidad: " + mesa.capacidad + " - Estado: " + estado);
        }
    }
}

// Clase Principal (Main)
public class AC {
    public static void main(String[] args) {
        // Crear restaurante
        Restaurante restaurante = new Restaurante("El Buen Sabor", "Calle Principal 123");

        // Crear mesas
        Mesa mesa1 = new Mesa(1, 4);
        Mesa mesa2 = new Mesa(2, 2);
        restaurante.agregarMesa(mesa1);
        restaurante.agregarMesa(mesa2);

        // Listar mesas
        restaurante.listarMesas();

        // Crear cliente
        Cliente cliente = new Cliente("Juan Pérez", "123456789");

        // Crear empleado
        Empleado empleado = new Empleado(1, "Ana López");

        // Realizar reserva
        Reserva reserva = cliente.realizarReserva("2024-12-10", "19:00", mesa1);
        if (reserva != null) {
            empleado.gestionarReservas(reserva);
        }

        // Listar mesas después de la reserva
        restaurante.listarMesas();

        // Finalizar reserva
        if (reserva != null) {
            reserva.finalizar();
        }

        // Listar mesas después de finalizar la reserva
        restaurante.listarMesas();
    }
}
